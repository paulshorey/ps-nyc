var isPrime = function(num) {
  ///... alex@aira.io
}
module.exports.primes = function(start,finish) {
  var primes = [];
  var i = start;
  while (i<=finish) {
    if (isPrime(i)) {
      primes.push(i);
    }
    i++;
  }
  return primes;
};

  // no for/forEach()
  // no arr.some() or arr.every()

module.exports.anyFound = function(arr, find) {
  return arr.indexOf(find)!==-1;
};

module.exports.allFound = function(arr, find) {
  return arr.reduce(function(allValue, currentValue) {
    return (currentValue === allValue) ? allValue : false; // :( oy! that reduce
  }, find);
};

module.exports.allTrue = function(arr) {
  return arr.reduce(function(allValue, currentValue) {
    return !!currentValue; // :( oy! that reduce
  });
};
