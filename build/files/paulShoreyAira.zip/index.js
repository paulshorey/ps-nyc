var { allFound, anyFound } = require('./functions');

var allTrue = [true,true,true,true,true,true,true,true,true];
var allFalse = [false,false,false,false,false,false,false,false];
var oneTrue = [false,false,false,false,false,true,false,false];
var allFalseButLast = [false,false,false,false,false,false,false,false,true];
var allFalseAlmost = [false,false,false,false,false,false,false,true,false];
var allTrueAlmost = [true,true,true,true,true,true,true,true,false,true];
var allTrueButLast = [true,true,true,true,true,true,true,,true,true,false];

// console.log(anyFound(oneTrue, true));

console.log(allFound(allTrue, true)); // expect: true 
console.log(allFound(oneTrue, true)); // expect: false
console.log(allFound(allTrueButLast, false)); // expect: false
console.log(allFound(allTrueAlmost, false)); // expect: false

console.log(allFound(allFalse, false)); // expect: true 
console.log(allFound(allFalseButLast, false)); // expect: false
console.log(allFound(allFalseAlmost, false)); // expect: false


