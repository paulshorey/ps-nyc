# 
# This was a very quick hacking session...
So, sorry it is not very impressive. But I did manage to find and include a very cute graphic of a pug's face. :)  
# 

# 
# Installation... 
```
npm install;
node index.js;
```
No time for unit tests of anything fancy, unfortunately. Barely remembered how to work with pug templating.  
  
# 
# 
Paul Shorey  
ps@artspaces.net  
385.770.6789  